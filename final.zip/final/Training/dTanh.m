function [ answer ] = dTanh( x )
answer=0.5*(1-tanh(x).^2);%dtanh
end

