%unmark the line below (keyboard)to stop execution 
%to continue just type return and Enter

%keyboard