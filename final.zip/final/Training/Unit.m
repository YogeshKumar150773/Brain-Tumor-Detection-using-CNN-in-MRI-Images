function [ answer ] = Unit( x )
	answer=x;
end