function [ answer ] = dRelu( x )
answer=double(x>0);%drelu
end