function [ answer ] = MSE( activation,expectedOut )
	answer= (activation-expectedOut);
end