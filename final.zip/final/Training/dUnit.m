function [ answer ] = dUnit( x )
	answer=1;
end